   <section class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   &copy;Online Library Management System |<a href="https://itsourcecode.com/" target="_blank"  > Designed by : SWARNAKSHI DUTTA</a> 
                </div>

            </div>
        </div>
    </section>
